   
    <footer class="section p-3 bg-dark text-white">
        <div class="text-center">&copy; Copyright <?php echo date("Y"); ?> Food Ordering System</div>
    </footer>
</body>
</html>